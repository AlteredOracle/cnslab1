#####################################################################################################
#
# Contrib
#
# NOTE: submitted conbtributions may have their own license. 
#       Please check the source of each file to see how you can use this software.
#
#####################################################################################################

[name]	                        [description]
run_rkhunter                    script: start rkhunter
rkhunter_remote_howto.txt       howto: run Rootkit Hunter from a central server.
